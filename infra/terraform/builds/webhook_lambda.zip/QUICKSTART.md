# 🚀 Quick Start - Webhook Lambda

Guia rápido para colocar o webhook em funcionamento.

## ⚡ 5 Minutos para Iniciar

### 1️⃣ Gerar Secret do GitHub

```bash
# Gerar uma string aleatória segura (32 bytes = 64 caracteres)
openssl rand -hex 32

# Exemplo de output:
# 2fa1ea24daf030cb54a2f9783391682d7a281736e4ffcd6ea312a0886e2991df
```

### 2️⃣ Armazenar Secret no AWS Parameter Store

```bash
aws ssm put-parameter \
  --name "/recyclops/GITHUB_WEBHOOK_SECRET" \
  --value "2fa1ea24daf030cb54a2f9783391682d7a281736e4ffcd6ea312a0886e2991df" \
  --type "SecureString" \
  --region us-east-1
```

### 3️⃣ Obter URL do Webhook (Output do Terraform)

```bash
cd infra/terraform

# Listar todos os outputs
terraform output

# Ou pegar apenas o webhook_url
terraform output webhook_url
# Resultado: https://gezmdkw6hj.execute-api.us-east-1.amazonaws.com/webhook
```

### 4️⃣ Configurar no GitHub

1. Vá para seu repositório
2. **Settings → Webhooks → Add webhook**
3. Preencha:
   - **Payload URL**: `https://gezmdkw6hj.execute-api.us-east-1.amazonaws.com/webhook` (copie do output)
   - **Content type**: `application/json` ✓
   - **Secret**: Cole o secret gerado no passo 1
   - **Which events would you like to trigger this webhook?**
     - ✅ Let me select individual events
     - ✅ Pull requests
     - ✅ Pushes
   - ✅ Active (checkbox deve estar marcado)
4. **Add webhook**

### 5️⃣ Testar o Webhook

**Via GitHub Interface:**

1. Vá para seu repositório
2. **Settings → Webhooks**
3. Clique no webhook criado
4. Seção **Recent Deliveries**
5. Clique em uma entrega e veja **Response**
   - Se vir `"status": "queued"` → ✅ **Funcionando!**

**Via Terminal:**

```bash
# Fazer um commit para triggar o webhook
git commit --allow-empty -m "Test webhook"
git push origin main

# Verificar mensagens na fila SQS
aws sqs receive-message \
  --queue-url https://sqs.us-east-1.amazonaws.com/656661782834/recyclops-accessibility.fifo \
  --region us-east-1
```

## 🔍 Verificação Detalhada

### Checar se Secret está configurado:

```bash
aws ssm get-parameter \
  --name "/recyclops/GITHUB_WEBHOOK_SECRET" \
  --with-decryption \
  --region us-east-1
```

### Ver logs do Lambda:

```bash
# Últimas 100 linhas de log
aws logs tail /aws/lambda/recyclops-webhook --follow

# Ou no console AWS:
# CloudWatch → Logs → /aws/lambda/recyclops-webhook
```

### Verificar mensagens na fila SQS:

```bash
aws sqs receive-message \
  --queue-url https://sqs.us-east-1.amazonaws.com/656661782834/recyclops-accessibility.fifo \
  --max-number-of-messages 10 \
  --region us-east-1 | jq '.Messages[] | .Body | fromjson'
```

## 📊 Checklist de Configuração

- [ ] Secret gerado com `openssl rand -hex 32`
- [ ] Secret armazenado no Parameter Store (`/recyclops/GITHUB_WEBHOOK_SECRET`)
- [ ] URL do webhook copiada do `terraform output`
- [ ] Webhook configurado no GitHub com:
  - [ ] Payload URL correta
  - [ ] Content type: `application/json`
  - [ ] Secret preenchido
  - [ ] Eventos: Pull requests + Pushes
  - [ ] Active: ✅ marcado
- [ ] Teste feito (commit + push)
- [ ] Mensagem aparece na fila SQS

## 🆘 Resolvendo Problemas

### "401 Unauthorized" no webhook

**Causa**: Secret incorreto

**Solução:**
```bash
# Verificar secret no Parameter Store
aws ssm get-parameter --name "/recyclops/GITHUB_WEBHOOK_SECRET" --with-decryption

# Certificar que é igual ao secret configurado no GitHub
# Settings → Webhooks → seu webhook → Secret
```

### Webhook não é acionado quando faço push

**Causa**: Repositório ou branch errado

**Solução:**
1. Confirme que está configurado no repositório correto
2. Faça um commit numa branch que o webhook está ouvindo
3. Verifique em **Settings → Webhooks → Recent Deliveries**

### Mensagens não aparecem na SQS

**Causa**: Lambda pode estar com erro

**Solução:**
1. Verifique logs no CloudWatch
2. Confirme que `SQS_URL` está configurado na Lambda
3. Verifique permissões IAM da Lambda

### "Invalid JSON" error

**Causa**: Body malformado ou vazio

**Solução:**
1. Confirme que o webhook está enviando JSON válido
2. Verifique no GitHub → Webhook → Recent Deliveries → Response

## 🧪 Teste Local (Opcional)

Para testar a lógica sem AWS:

```bash
cd /caminho/para/recyclops
python3 test_webhook.py
```

Deve mostrar:
```
5/5 testes passaram ✅
```

## 📖 Referências

- [Webhook Requests - GitHub Docs](https://docs.github.com/en/developers/webhooks-and-events/webhooks/creating-webhooks)
- [Securing your webhooks - GitHub Docs](https://docs.github.com/en/developers/webhooks-and-events/webhooks/securing-your-webhooks)
- [Handler README](./README.md) - Documentação completa

## 💡 Pro Tips

1. **Teste com webhooks de teste do GitHub:**
   - GitHub → Webhook → **Test Delivery** button
   - Simula um evento sem precisar fazer commit

2. **Use CloudWatch para monitorar:**
   ```bash
   aws logs tail /aws/lambda/recyclops-webhook --follow
   ```

3. **Inspecione mensagens da SQS:**
   ```bash
   aws sqs receive-message \
     --queue-url $SQS_URL \
     --max-number-of-messages 1 | jq '.Messages[0].Body | fromjson | .'
   ```

4. **Reseta a fila se necessário:**
   ```bash
   # Purga todas as mensagens (cuidado!)
   aws sqs purge-queue --queue-url $SQS_URL
   ```

---

**Tempo estimado**: 5-10 minutos ⏱️

**Status**: ✅ Pronto para começar

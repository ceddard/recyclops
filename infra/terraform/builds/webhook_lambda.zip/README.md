# GitHub Webhook Lambda Handler

Handler Lambda para processar eventos do GitHub e enviar para a fila SQS para análise de acessibilidade.

## 📋 Visão Geral

Este serviço atua como intermediário entre GitHub e a pipeline de análise do Recyclops:

```
GitHub Webhook
      ↓
   Lambda (validação + parsing)
      ↓
   SQS FIFO Queue
      ↓
   Analyzer (ECS Worker)
```

## 🔐 Validação de Assinatura

O handler valida **todas as requisições** usando HMAC-SHA256 conforme padrão do GitHub:

### Como funciona:

1. GitHub envia o webhook com header: `x-hub-signature-256: sha256=<hash>`
2. O handler calcula o HMAC-SHA256 do body com o secret do GitHub
3. Compara de forma timing-safe usando `hmac.compare_digest()`
4. Rejeita se as assinaturas não baterem

### Configuração:

O secret é carregado de **AWS Systems Manager Parameter Store**:

```python
WEBHOOK_SECRET_PARAM = os.environ["WEBHOOK_SECRET_PARAM"]
# Exemplo: "/recyclops/GITHUB_WEBHOOK_SECRET"
```

**Variáveis de Ambiente Obrigatórias:**
- `WEBHOOK_SECRET_PARAM`: Caminho do Parameter Store com o secret do GitHub
- `SQS_URL`: URL da fila SQS FIFO

## 📨 Eventos Suportados

### 1. Pull Request Events

**Ações processadas:**
- `opened` - Novo PR criado
- `synchronize` - Commits foram adicionados ao PR
- `reopened` - PR foi reabrerto

**Ações ignoradas:**
- `closed`, `labeled`, `unlabeled`, `assigned`, etc.

**Formato da mensagem:**

```json
{
  "event_type": "pull_request",
  "action": "opened",
  "repo": "owner/repo-name",
  "pr_number": 42,
  "pr_title": "Fix accessibility issues",
  "head_sha": "abc123def456",
  "head_ref": "feature/accessibility",
  "base_ref": "main",
  "author": "github-username"
}
```

### 2. Push Events

**Eventos processados:**
- Push em branches (ignora tags)
- Envia apenas o último commit da sequência

**Eventos ignorados:**
- Tag pushes (`refs/tags/*`)
- Branches vazios

**Formato da mensagem:**

```json
{
  "event_type": "push",
  "repo": "owner/repo-name",
  "branch": "main",
  "head_sha": "commit-sha",
  "commit_message": "Update code",
  "author": "github-username",
  "num_commits": 2
}
```

## 🚀 Respostas HTTP

| Status | Cenário | Resposta |
|--------|---------|----------|
| **200** | Webhook válido e enfileirado | `{"status": "queued", "messageId": "...", "event": "..."}` |
| **200** | Evento ignorado por filtros | `{"status": "filtered"}` |
| **400** | JSON inválido | `{"error": "Invalid JSON"}` |
| **401** | Assinatura inválida | `{"error": "Invalid signature"}` |
| **500** | Erro interno | `{"error": "Internal server error"}` |

## 🧪 Testes

Veja o arquivo `test_webhook.py` na raiz do projeto para validar a lógica do handler.

### Executar testes:

```bash
cd /path/to/recyclops
python3 test_webhook.py
```

### Cobertura de testes:

- ✅ Validação de assinatura HMAC
- ✅ Parsing de eventos JSON
- ✅ Filtragem de eventos
- ✅ Formato de mensagens SQS
- ✅ Tratamento de erros

## 📊 Fluxo de Processamento

```
┌─────────────────────┐
│  GitHub Webhook     │
│  POST /webhook      │
└──────────┬──────────┘
           │
           ↓
     ┌─────────────────┐
     │ Validar         │
     │ Assinatura HMAC │
     └────┬────────┬───┘
          │        └──→ ❌ 401 Unauthorized
          │
          ↓
     ┌─────────────────┐
     │ Parsear JSON    │
     └────┬────────┬───┘
          │        └──→ ❌ 400 Bad Request
          │
          ↓
  ┌──────────────────┐
  │ Identificar tipo │
  │ de evento        │
  └────┬─────────┬──┘
       │         └──→ ❌ 200 Ignored (event type não suportado)
       │
       ↓
  ┌──────────────────┐
  │ Filtrar por      │
  │ ação/branch      │
  └────┬─────────┬──┘
       │         └──→ ✅ 200 Filtered (dentro de regras)
       │
       ↓
  ┌──────────────────┐
  │ Enviar para SQS  │
  └────┬─────────┬──┘
       │         └──→ ❌ 500 Error
       │
       ↓
    ✅ 200 OK - Mensagem enfileirada
```

## 🔧 Configuração no GitHub

### 1. Gerar Secret

```bash
openssl rand -hex 32
```

Armazene este valor em **AWS Systems Manager Parameter Store**:

```bash
aws ssm put-parameter \
  --name "/recyclops/GITHUB_WEBHOOK_SECRET" \
  --value "seu-secret-gerado" \
  --type "SecureString"
```

### 2. Configurar Webhook no GitHub

1. Vá para seu repositório
2. **Settings → Webhooks → Add webhook**
3. Configure:
   - **Payload URL**: `https://seu-api-gateway.execute-api.us-east-1.amazonaws.com/webhook`
   - **Content type**: `application/json`
   - **Secret**: Cole o secret gerado (mesmo valor do Parameter Store)
   - **Events**: Selecione `Pull requests` e `Pushes`
   - **Active**: ✅ Habilitado

### 3. Copiar URL do API Gateway

A URL do webhook é disponibilizada via Terraform output:

```bash
terraform output webhook_url
# Resultado: https://gezmdkw6hj.execute-api.us-east-1.amazonaws.com/webhook
```

## 📝 Logs e Monitoramento

Todos os eventos são logados em **CloudWatch Logs** em `/aws/lambda/recyclops-webhook`:

### Log de sucesso:

```
✅ Mensagem enfileirada | Type: pull_request | Repo: owner/repo | SHA: abc123de | MessageId: xxx-yyy-zzz
```

### Log de erro:

```
❌ Assinatura GitHub inválida
```

## 🔄 Fluxo Completo de um PR

1. **GitHub**: Novo PR é criado → envia webhook
2. **Lambda**: Valida assinatura → parseia evento → enfileira em SQS
3. **SQS**: Armazena mensagem (FIFO garante ordem)
4. **Analyzer**: Consome mensagem → chama CERS-IA → salva resultado
5. **GitHub**: Comentário é adicionado ao PR com resultado

## 🚨 Troubleshooting

| Problema | Causa Provável | Solução |
|----------|---|---|
| 401 Unauthorized | Assinatura inválida | Verifique se o secret está correto no Parameter Store |
| 500 Error | SQS_URL não configurado | Configure variável de ambiente `SQS_URL` |
| Webhook não funciona | URL errada no GitHub | Verifique output do Terraform e copie URL correta |
| Mensagens da fila vazia | Webhook não é chamado | Faça commit real no GitHub para triggar webhook |

## 📚 Referências

- [GitHub Webhook Documentation](https://docs.github.com/en/developers/webhooks-and-events/webhooks/about-webhooks)
- [GitHub Webhook Signature Verification](https://docs.github.com/en/developers/webhooks-and-events/webhooks/securing-your-webhooks)
- [AWS Lambda Environment Variables](https://docs.aws.amazon.com/lambda/latest/dg/configuration-envvars.html)
- [AWS Systems Manager Parameter Store](https://docs.aws.amazon.com/systems-manager/latest/userguide/systems-manager-parameter-store.html)

## 📦 Dependências

```
boto3==1.35.0    # AWS SDK
```

(Já incluídas no `requirements.txt`)

## ✨ Melhorias Futuras

- [ ] Implementar retry automático com DLQ
- [ ] Validar se o repositório está autorizado
- [ ] Suporte a múltiplos eventos GitHub
- [ ] Rate limiting per repository
- [ ] Histórico de webhooks recebidos

---

**Status**: ✅ Pronto para produção

**Última atualização**: 5 de Março de 2026

# Exemplos de Webhooks do GitHub

Payloads reais dos webhooks processados pelo handler.

## Pull Request - Opened

```json
{
  "action": "opened",
  "number": 42,
  "pull_request": {
    "id": 1,
    "title": "Add accessibility checks",
    "body": "This PR improves accessibility scanning",
    "head": {
      "ref": "feature/accessibility",
      "sha": "abc123def456",
      "user": {
        "login": "developer1"
      }
    },
    "base": {
      "ref": "main",
      "sha": "xyz789"
    },
    "user": {
      "login": "developer1"
    }
  },
  "repository": {
    "id": 123456,
    "name": "recyclops",
    "full_name": "carloseduardosoares/recyclops",
    "private": false,
    "html_url": "https://github.com/carloseduardosoares/recyclops"
  }
}
```

**Mensagem SQS enviada:**

```json
{
  "event_type": "pull_request",
  "action": "opened",
  "repo": "carloseduardosoares/recyclops",
  "pr_number": 42,
  "pr_title": "Add accessibility checks",
  "head_sha": "abc123def456",
  "head_ref": "feature/accessibility",
  "base_ref": "main",
  "author": "developer1"
}
```

## Pull Request - Synchronize (novo commit)

Quando o usuário faz push de novos commits no PR:

```json
{
  "action": "synchronize",
  "number": 42,
  "pull_request": {
    "id": 1,
    "title": "Add accessibility checks",
    "head": {
      "ref": "feature/accessibility",
      "sha": "def456ghi789",
      "user": {
        "login": "developer1"
      }
    },
    "base": {
      "ref": "main"
    },
    "user": {
      "login": "developer1"
    }
  },
  "repository": {
    "full_name": "carloseduardosoares/recyclops"
  }
}
```

**Mensagem SQS:**

```json
{
  "event_type": "pull_request",
  "action": "synchronize",
  "repo": "carloseduardosoares/recyclops",
  "pr_number": 42,
  "pr_title": "Add accessibility checks",
  "head_sha": "def456ghi789",
  "head_ref": "feature/accessibility",
  "base_ref": "main",
  "author": "developer1"
}
```

## Push - Branch Main

```json
{
  "ref": "refs/heads/main",
  "before": "xyz789",
  "after": "abc123def456",
  "pusher": {
    "name": "developer1",
    "email": "dev@example.com"
  },
  "commits": [
    {
      "id": "abc123def456",
      "tree_id": "tree123",
      "message": "Update accessibility tests",
      "author": {
        "name": "Developer One",
        "email": "dev@example.com"
      }
    },
    {
      "id": "def456ghi789",
      "tree_id": "tree456",
      "message": "Fix formatting",
      "author": {
        "name": "Developer One",
        "email": "dev@example.com"
      }
    }
  ],
  "head_commit": {
    "id": "def456ghi789",
    "message": "Fix formatting"
  },
  "repository": {
    "id": 123456,
    "name": "recyclops",
    "full_name": "carloseduardosoares/recyclops",
    "private": false
  }
}
```

**Mensagem SQS (apenas último commit):**

```json
{
  "event_type": "push",
  "repo": "carloseduardosoares/recyclops",
  "branch": "main",
  "head_sha": "def456ghi789",
  "commit_message": "Fix formatting",
  "author": "developer1",
  "num_commits": 2
}
```

## Eventos IGNORADOS

Estes eventos chegam ao Lambda mas são ignorados:

### PR Closed

```json
{
  "action": "closed",
  "pull_request": { ... }
}
```

**Resultado:** `200 OK` com `{"status": "filtered"}`

### PR Labeled

```json
{
  "action": "labeled",
  "pull_request": { ... }
}
```

**Resultado:** `200 OK` com `{"status": "filtered"}`

### Push Tag

```json
{
  "ref": "refs/tags/v1.0.0",
  "commits": [ ... ]
}
```

**Resultado:** `200 OK` com `{"status": "filtered"}`

## Erro - Assinatura Inválida

Requisição com header `x-hub-signature-256` incorreto:

```
POST /webhook HTTP/1.1
x-hub-signature-256: sha256=invalid_signature
x-github-event: pull_request
Content-Type: application/json

{"action":"opened",...}
```

**Resultado:** `401 Unauthorized`

```json
{
  "error": "Invalid signature"
}
```

## Erro - JSON Inválido

Body não é JSON válido:

```
POST /webhook HTTP/1.1
x-hub-signature-256: sha256=valid_signature
x-github-event: pull_request

{invalid json}
```

**Resultado:** `400 Bad Request`

```json
{
  "error": "Invalid JSON"
}
```

## Header de Requisição Completo

Exemplo de headers enviados pelo GitHub:

```
POST /webhook HTTP/1.1
Host: api.example.com
Content-Type: application/json
Content-Length: 2345
User-Agent: GitHub-Hookshot/abc123
X-GitHub-Delivery: 12345678-1234-1234-1234-123456789012
X-GitHub-Event: pull_request
X-GitHub-Hook-ID: 123456789
X-GitHub-Hook-Installation-Target-ID: 123456
X-GitHub-Hook-Installation-Target-Type: repository
X-Hub-Signature: sha1=52412caa586efd17e34a5fb50a944e23fb0c6b78
X-Hub-Signature-256: sha256=abc123def456ghi789xyz

{
  "action": "opened",
  ...
}
```

**Headers importantes para o handler:**

- `x-github-event`: Tipo de evento (`pull_request`, `push`, etc)
- `x-hub-signature-256`: Assinatura HMAC-SHA256 para validação
- `Content-Type`: Sempre `application/json`

---

**Última atualização**: 5 de Março de 2026
